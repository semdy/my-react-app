import React, { useReducer } from 'react'
import NetCallContext from '@/context/NetCallContext'
import reducer, { initialState } from './index'

let reducerState = {}

function wrapperDispatch(dispatch) {
  return function handler(action) {
    if (typeof action === 'function') {
      action(handler, () => reducerState)
    } else {
      dispatch(action)
    }
  }
}

export default ({ children }) => {
  const [state, dispatch] = useReducer(reducer, initialState)
  reducerState = state

  return (
    <NetCallContext.Provider value={[state, wrapperDispatch(dispatch)]}>
      {children}
    </NetCallContext.Provider>
  )
}
