export default function initNetCallSDK() {
  return async (dispatch, getState) => {
    const Netcall = await import('./netcall')
    window.netcall = new Netcall.default(dispatch, getState) // eslint-disable-line new-cap
    return window.netcall
  }
}
